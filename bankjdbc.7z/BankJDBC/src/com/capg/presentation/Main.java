package com.capg.presentation;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capg.beans.Bankdetails;
import com.capg.beans.Transaction;
import com.capg.exception.BankException;
import com.capg.service.BankServiceImpl;

public class Main {
	static Scanner scanner = null;
	static String name;
	static String mobile;
	 static  int transactionId;
	static String accountNo;
	static String choices;
	static double balance;
	static int flow = 0;
	static Main object = new Main();
	static BankServiceImpl service = new BankServiceImpl();
	private double amount;
	boolean result;
	private int transaction;
	private int AccountFlag = 0;
	static int welcomeFlag = 0;
	static int choice2 = 0;
	static boolean bool = true;
	private static int LoginFlag;

	public static void main(String[] args)
	{
System.out.println("****Banking App****** ");
		
		do {
			System.out.println(" 1. Create Account \t\t\t 2. Log In");
			System.out.print("enter your choice : ");
			scanner = new Scanner(System.in);
			int choice = scanner.nextInt();
			if (choice == 1)
			{
				try {
					object.createAccount();
				} catch (BankException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else if (choice == 2)
			{
				scanner = new Scanner(System.in);
				System.out.print(" enter Username:");
				String user = scanner.nextLine();
				System.out.print("set Password :");
				String pass = scanner.nextLine();
                Bankdetails bank = service.login(user, pass);
						if (bank == null)
								{
								System.err.println("Invalid Username/Password");
									LoginFlag = 0;
								}
							else 
							{
									System.err.println(" login successfull ");
									name = bank.getName();
									mobile = bank.getMobile();
									accountNo = bank.getAccountNum();
									balance = bank.getBalance();
										try {
											usermenu();
										} catch (BankException e) {
											
											e.printStackTrace();
										}
									
									catch(InputMismatchException e)
									{
										System.err.println("Please Enter Valid Input");
									}
					LoginFlag = 1;

				}
			}

		} while (LoginFlag == 0);
	}

	private static void usermenu() throws BankException {
		
do {
	System.out.println("The following services are available:   ");
			
			do {
				System.out.println("\n 1.Account Balance \n 2.Deposit ");
				System.out.println("3. Withdraw	\n	    4.Transfer\n");
				System.out.println("5. Account Statement \n 6. Exit\n");
				System.out.print("enter  your choice:  ");
				scanner = new Scanner(System.in);
				choice2 = scanner.nextInt();
				switch (choice2) {
				case 1:
					object.showBalance();
					break;
				case 2:object.deposit();
				break;
						

				case 3:object.withdraw();
				break;
						

				case 4:object.transfer();
				break;
						
				case 5:object.printTransactions();
				break;
						

				case 6:System.err.println("Thanks  for visiting");
				System.exit(0);			

				default:
					System.err.println("Invalid option.Please enter options between 1-6..");
				}

			do {
				System.out.println("\nDo you wish to Continue ? (Y= yes/N= no)");
				scanner = new Scanner(System.in);
				choices = scanner.nextLine();
				if (choices.equalsIgnoreCase("y") || choices.equalsIgnoreCase("n"))
					bool = false;
				else {
					System.err.println("Invalid Input!! Enter Y or N");
					bool = true;
				}
				}while(!choices.equalsIgnoreCase("y") && !choices.equalsIgnoreCase("n"));
			} while (bool);
			if (choices.equalsIgnoreCase("n"))
				System.err.println(" " + name + " !! Your session has been Logged Out from Capgemini");
			
		} while (choices.equalsIgnoreCase("y"));
			
	}

	private void printTransactions() {
		List<Transaction> Translist = new ArrayList<>();
		Translist = service.printAllTransactions(accountNo);
        System.out.println("  Account Statement");
	    System.out.println("Account Number : " + accountNo);
		System.out.println("Account Name   : " + name);
		System.out.println("Account Mobile : " + mobile);
		System.out.println("Account Type   : Savings Bank");
		System.out.println("  Amount \t Balance \t date \t details \t Transacton Id \t   ");
		       Iterator<Transaction> iterator = Translist.iterator();
		            while (iterator.hasNext())
		             System.out.println(iterator.next());
		
	}

	private void transfer() {
		scanner = new Scanner(System.in);
		System.out.println("Transferring.......");
		System.out.print(" Account No : ");
		String recieverAccountNo = scanner.nextLine();
		try {
			System.out.print(" Amount :");
			amount = scanner.nextDouble();
		} catch (InputMismatchException e) {
			System.out.println("Please Enter Valid Amount");
		}

		result = service.details("debit", amount,accountNo);
		if(!result)
			
			System.err.println("Not Enough balance in your Account");
		
		else {
		balance = service.balance(accountNo);
		String transfer = "Transfer to " + recieverAccountNo;
     
		Transaction transact = new Transaction( amount, balance, LocalDate.now().toString(), transfer,transactionId);
		transaction = service.addTransact(transact, accountNo);

		service.details("credit", amount,recieverAccountNo);
		Transaction transferobject = new Transaction( amount, balance, LocalDate.now().toString(),
				"Credit || Transfer from " + accountNo,transactionId);
		service.addTransact(transferobject, recieverAccountNo);

		System.out.print("Transaction successful. Your Transaction No. " +transaction);
		}
	}

	private void withdraw() {
		scanner = new Scanner(System.in);
		System.out.println("  Withdrawing ");
	
	
		try {
			System.out.print(" Amount :");
			amount = scanner.nextDouble();
		} catch (InputMismatchException e) {
			System.out.println("Please Enter Valid Amount");
		}
		result = service.details("debit", amount,accountNo);
		if(!result)
			System.err.println("Insufficient balance in your Account..!!");
		else {
		balance = service.balance(accountNo);
         Transaction trans = new Transaction( amount, balance, LocalDate.now().toString(), "Debit",transactionId);
         transaction = service.addTransact(trans, accountNo);
		System.out.print("Transaction successful. Your Transaction No. ");
		System.err.print(transaction);
		
		}
	}

	private void deposit() {
		scanner = new Scanner(System.in);
		System.out.println(" Depositing \n");
		try {
			System.out.print(" Amount :");
			amount = scanner.nextDouble();
		} catch (InputMismatchException e) {      
			System.out.println("Invalid Amount");
		}
		result = service.details("credit", amount,accountNo);
		
		balance = service.balance(accountNo);

		Transaction trans = new Transaction(amount, balance, LocalDate.now().toString(), "Credit",0);

		transaction = service.addTransact(trans, accountNo);

		System.out.print("Transaction successful. Your Transaction No. "+transaction);
		System.err.print(transaction);
		
	
	}

	private void showBalance() 
	{
		System.out.println("\nAccount Number : " + accountNo);
		System.out.println("Account Name   : " + name);
		System.out.println("Account Mobile :" + ", " + mobile);
		System.out.println("Account Type   : Savings Bank");
		balance = service.balance(accountNo);
		System.out.print("Balance Available as on " + LocalDate.now() + " : "+balance);
		
		
	}

	private void createAccount() throws BankException {
			System.out.println("Registration of New User  ");
					System.out.print("Full Name: ");
					scanner = new Scanner(System.in);
					name = scanner.nextLine();
					
					 try {
						 service.isNamevalid(name);
							} catch (BankException e)
						{
								throw new BankException("Invalid Name(First letter Must be Capital)");
								
						}
						do {
							System.out.print("Mobile :");
							mobile = scanner.nextLine();
							
							
							try {
								service.isPhonevalid(mobile);
							} 
							catch (BankException e)
							{
								throw new BankException("Invalid Mobile Number(Must have 10 digit and start with 6,7,8 or 9)");						
						
								}
							System.out.println("enter address:");
							String address=scanner.nextLine();
							System.out.print("Choose Username :");
							String username = scanner.nextLine();
							System.out.print("Choose Password :");
							String password = scanner.nextLine();
						    int accountNo1 = service.accountNo();
							accountNo = "BANK" + accountNo1;
							System.out.println("Account Created successfully....your Account No: " + accountNo);
							Bankdetails banking = new Bankdetails(accountNo,username,password,name,mobile,address,2000);
							service.addCustomer(banking);
							scanner = new Scanner(System.in);
					
       } while (!service.isNamevalid(name));

	}
}
		
	
					
					
				

	

	


