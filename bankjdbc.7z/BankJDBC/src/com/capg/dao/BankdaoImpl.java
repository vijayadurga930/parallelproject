package com.capg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capg.beans.Bankdetails;
import com.capg.beans.Transaction;
import com.capg.utility.DBConnection;

public class BankdaoImpl implements IBankdao {
	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet resultSet = null;
	int row = -1;
	int authorId = 0;
	static boolean status=false;
	List<Transaction> transList=null;
	
	@Override
	public void createTable(String accountNo)
	{
		try(Connection connection = DBConnection.getConnection();) {
			statement=connection.prepareStatement("create table "+accountNo+" (TId number(10) primary key,"+"Amount Number(10), "+"Balance Number(10),"+"Transaction_Date varchar2(20),"+"details varchar2(25))");
			status=statement.execute();
			System.out.println("Transaction occured");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
	
	@Override
	public boolean insertToTransaction(Transaction tran, int transactId,String AccountNo) {
		try (Connection connection = DBConnection.getConnection();) {
			statement = connection.prepareStatement("insert into "+ AccountNo +" values (?,?,?,?,?)");
			System.out.println(tran.getTranscationId());
			
			statement.setDouble(1, tran.getAmount());
			statement.setDouble(2, tran.getBalance());
			statement.setString(3, tran.getDate());
			statement.setString(4, tran.getDetails());
			statement.setInt(5, tran.getTranscationId());
			row = statement.executeUpdate();
			return true;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return false;
	}
	
	@Override
	public boolean insertIntoBanking(Bankdetails banking)
	{ 
		try (Connection connection = DBConnection.getConnection();)
		{
		
			statement = connection.prepareStatement("insert into Banking values(?,?,?,?,?,?)");			
			statement.setString(1,banking.getUsername());
			statement.setString(2,banking.getPassword());
			statement.setString(3,banking.getAccountNum());
			statement.setString(4, banking.getName());
			statement.setString(5,banking.getMobile());
			statement.setDouble(6,banking.getBalance());
			row = statement.executeUpdate();
			return true;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return false;
	}
	
	@Override
	public List<Transaction> getAllTransaction(String AccountNo)
	{    transList= new ArrayList<>();
		try (Connection connection = DBConnection.getConnection();) {
			statement = connection.prepareStatement("select * from Transaction "+AccountNo);
System.out.println("select * from "+AccountNo);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				Transaction trans = new Transaction();
				trans.setTranscationId(resultSet.getInt("TID"));
				trans.setAmount(resultSet.getDouble("Amount"));
				trans.setBalance(resultSet.getDouble("Balance"));
				trans.setDate(resultSet.getString("Transaction_Date"));
				trans.setDetails(resultSet.getString("details"));
				transList.add(trans);
			}
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		return transList;		
	}

	@Override
	public Bankdetails loginUser(String user, String pass) {
		try (Connection connection = DBConnection.getConnection();) {
			statement = connection.prepareStatement("select * from  Banking");
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
			if(resultSet.getString("Username").contentEquals(user) && resultSet.getString("Password").contentEquals(pass)) {
				Bankdetails bank=new Bankdetails ();
				bank.setUsername(user);
				bank.setPassword(pass);
				bank.setAccountNum(resultSet.getString("AccountNum"));
			    bank.setName(resultSet.getString("Name"));
				bank.setMobile(resultSet.getString("Mobile"));
				bank.setBalance(resultSet.getDouble("Balance"));
				return bank;
			}				
		}	
		
	} catch (SQLException e) {
		e.printStackTrace();
	}return null;
	

	}

	@Override
	public double balance(String accountNo) {
		try (Connection connection = DBConnection.getConnection();) {
			statement = connection.prepareStatement("select  balance from  Banking where AccountNum ='"+accountNo+"'");
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
			return resultSet.getDouble("Balance");
			}				
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		return 0;
	}

	@Override
	public void updateBalance(double balance, String accountNo) {
		try (Connection connection = DBConnection.getConnection();) {
			statement = connection.prepareStatement("update Banking  set balance= "+balance+"where AccountNum ='"+accountNo+"'");
			resultSet = statement.executeQuery();	
		} catch (SQLException e) {
			e.printStackTrace();
		}	
	}
	
}
	