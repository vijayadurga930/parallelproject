package com.capg.dao;

import java.util.List;

import com.capg.beans.Bankdetails;
import com.capg.beans.Transaction;

public interface IBankdao {
	boolean insertToTransaction(Transaction tran, int transactId, String AccountNo);
	boolean insertIntoBanking(Bankdetails banking);
	List<Transaction> getAllTransaction(String AccountNo);
	void createTable(String accountNo);
	
	Bankdetails loginUser(String user, String pass);
	double balance(String accountNo);
	void updateBalance(double balance, String accountNo2);

}
