package com.capg.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capg.beans.Bankdetails;
import com.capg.beans.Transaction;
import com.capg.dao.BankdaoImpl;
import com.capg.dao.IBankdao;
import com.capg.exception.BankException;

public class BankServiceImpl implements IBankservice{
	int transactId = 0;double accountNo;
	IBankdao dao=new BankdaoImpl();
	static private double balance;

	@Override
	public int accountNo() {
		accountNo = (Math.random() *10000000);
		return (int) accountNo;
	}

	@Override
	public boolean isPhonevalid(String phone) throws BankException {
		Pattern nameptn = Pattern.compile("^[6-9]{1}[0-9]{9}$");
		Matcher match = nameptn.matcher(phone);
		if (match.matches())
			return true;
		else
		return false;
	}

	

	@Override
	public boolean isNamevalid(String name) throws BankException {
		Pattern nameptn = Pattern.compile("^[A-Z]*[a-z]*[//s]*$");
		Matcher match = nameptn.matcher(name);
		if (match.matches()) {
			return true;
		}
		else
	
		return false;
	}

	


	@Override
	public List<Transaction> printAllTransactions(String AccoutnNo) {
		List<Transaction> transactList=new ArrayList<>();
		transactList.addAll(dao.getAllTransaction(AccoutnNo));
		return transactList;

	}

	@Override
	public boolean addCustomer(Bankdetails banking) {
		boolean status = dao.insertIntoBanking(banking);
		dao.createTable(banking.getAccountNum());
			
		return status;

	}

	@Override
	public double balance(String accountNo) {
		
		return dao.balance(accountNo);
	}

	@Override
	public boolean details(String type, double amount, String accountNo2) {

		if((balance <0 || balance == 0) && (type.equals("debit") || type.equals("transfer")))
			return false;
		else {
			
		switch(type)
		{
		case "debit":{ 
			balance = balance-amount;
			}	
		break;
		case "credit": {
			balance= balance+amount;
			} break;
		case "transfer":{
			balance= balance-amount;
			}
		break;
		}
		dao.updateBalance(balance,accountNo2);
		
		if(type.equals("debit") || type.equals("credit") || type.equals("transfer"))
	  	return true;
		}
	
		return false;
	}

	@Override
	public int addTransact(Transaction transact, String account) {
		transactId = (int) (Math.random() *1000);
		transact.setTranscationId(transactId);
		boolean status = dao.insertToTransaction(transact, transactId, account);
		if (status)
			return transactId;
		

		return 0;
	}

	public Bankdetails login(String user, String pass) {
		Bankdetails bank=dao.loginUser(user,pass);
		return bank;

	}

}
