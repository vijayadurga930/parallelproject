package com.cg.presentation;

import java.util.ArrayList;
import java.util.Scanner;

import com.capg.bean.BankBean;
import com.capg.service.BankServiceImpl;

public class Main {

	public static void main(String[] args) {
		BankServiceImpl service = new BankServiceImpl();
		Scanner scanner = new Scanner(System.in);
		int choice;
		do {
			System.out.println("\n\t\t\t\tWelcome to My Bank Services");
			System.out.println("********************************************************************************************************");
			System.out.println(
					"1.Create Account\n2.Show Balance\n3.Deposit Amount\n4.Withdraw Amount\n5.FundTransfer\n6.Print Transaction Details\n7.Exit");
			System.out.print("Enter Your Choice: ");
			choice = scanner.nextInt();
			switch (choice) {
			case 1:
				System.out.print("Enter Name:");
				String name = scanner.next();
				System.out.print("Enter Mobile Number: ");
				String mobileno = scanner.next();
				System.out.print("Enter Initial Amount: ");
				double amount = scanner.nextDouble();
				System.out.print("Enter City: ");
				String city = scanner.next();
				System.out.print("Enter State: ");
				String state = scanner.next();
				BankBean bean = new BankBean(name, mobileno, amount, city, state);
				BankBean bank = service.addAccount(bean);
				System.out.println("------------------------------------------------------------");
				System.out.println("Thank you " + name + " Your Account is created Successully");
				int accountId=0;
				accountId=service.getId(accountId);
				System.out.println(" your account id:"+accountId);
				break;
			case 2:
				System.out.print("Enter Account Id: ");
				int account_id = scanner.nextInt();
				bank = service.getAccountBalence(account_id);
				System.out.println("-------------------------------------------------------------------------");
				System.out.println(
						"Hello " + bank.getCustomer_name() + "\nYour Current Account Balance is " + bank.getAmount());
				break;
			case 3:
				System.out.print("Enter Account Id: ");
				account_id = scanner.nextInt();
				System.out.print("Enter Amount to be Deposited: ");
				amount = scanner.nextDouble();
				bank = service.deposit(account_id, amount);
				System.out.println("------------------------------------------------------------------------");
				System.out.println("Hello " + bank.getCustomer_name() + " Your Amount is Deposited Succesfully");
				System.out.println("Your Current Account Balence is " + bank.getAmount());
				break;
			case 4:
				System.out.print("Enter Account Id: ");
				account_id = scanner.nextInt();
				System.out.print("Enter Amount to be WithDrawn: ");
				amount = scanner.nextDouble();
				bank = service.withdraw(account_id, amount);
				System.out.println("------------------------------------------------------------------------");
				System.out.println("Hello " + bank.getCustomer_name() + " Your Amount is Withdrawn Succesfully");
				System.out.println("Your Current Account Balence is " + bank.getAmount());
				break;
				
			case 5:System.out.print("Enter Your Account Id: ");
			int account_id1 = scanner.nextInt();
			System.out.print("Enter Account Id of person you want to transfer Amount: ");
			int account_id2 = scanner.nextInt();
			System.out.print("Enter Amount to be Transfered: ");
			amount = scanner.nextDouble();
			bank = service.fundTransfer(account_id1, account_id2, amount);
			System.out.println("-----------------------------------------------------------------------------");
			System.out.println("Hello " + bank.getCustomer_name() + " Your Amount is Transferred Succesfully\n");
			System.out.println("Your Current Account Balence is " + bank.getAmount());

				
				break;
			case 6:
				System.out.print("Enter Your Account Number to Know Your Transaction Details:");
				account_id = scanner.nextInt();
				ArrayList a = service.printDetails(account_id);
				System.out.println("Transaction_Id Account_Id    Transaction_Date     Transaction_Amount Transaction_Type");
				System.out.println("_______________________________________________________________________________________");
				for(Object i:a)
				System.out.println(i+"\n");
				System.out.println("_______________________________________________________________________________________");
				break;
			case 7:
				System.out.println("Thank for Using our Bank Services....!!!");
				break;

			}

		} while (choice != 7);
	}

	}


