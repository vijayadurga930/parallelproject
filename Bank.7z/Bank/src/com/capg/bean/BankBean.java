package com.capg.bean;

public class BankBean {

	private int account_id;
	private String customer_name;
	private String contact_number;
	private double amount;
	private String city;
	private String state;
	public BankBean( String customer_name, String contact_number, double amount, String city,
			String state) {
		super();

		this.customer_name = customer_name;
		this.contact_number = contact_number;
		this.amount = amount;
		this.city = city;
		this.state = state;
	}
	public BankBean() {
		super();
	}
	@Override
	public String toString() {
		return "BankBean [account_id=" + account_id + ", customer_name=" + customer_name + ", contact_number="
				+ contact_number + ", amount=" + amount + ", city=" + city + ", state=" + state + "]";
	}
	public int getAccount_id() {
		return account_id;
	}
	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getContact_number() {
		return contact_number;
	}
	public void setContact_number(String contact_number) {
		this.contact_number = contact_number;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	
}
