package com.capg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


import com.capg.bean.BankBean;

public class BankdaoImpl implements IBankdao{

	@Override
	public BankBean addAccount(BankBean bean) {
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("insert into BankBean values(?,?,?,?,?,?)");
			p.setInt(1,bean.getAccount_id());
			p.setString(2, bean.getCustomer_name());
			p.setString(3, bean.getContact_number());
			p.setDouble(4, bean.getAmount());
			p.setString(5, bean.getCity());
			p.setString(6, bean.getState());
			p.executeUpdate();
			
		
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("Select * from BankBean");
			if (rs.next())
				bean.setAccount_id(rs.getInt(1));

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return bean;
	}

	@Override
	public BankBean getAccountBalence(int account_id) {
		BankBean bank = new BankBean();
		Connection conn = DBConnection.getConnection();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from BankBean where account_id=" + account_id);
			while (rs.next()) {
				bank.setAccount_id(rs.getInt(1));
				bank.setCustomer_name(rs.getString(2));
				bank.setAmount(rs.getDouble(4));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return bank;
	}

	@Override
	public BankBean deposit(int account_id, double amount) {
		BankBean b = new BankBean();
		Connection conn = DBConnection.getConnection();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from BankBean where account_id=" + account_id);
			while (rs.next()) {
				b.setAccount_id(rs.getInt(1));
				b.setCustomer_name(rs.getString(2));
				b.setAmount(rs.getDouble(4) + amount);
			}
			PreparedStatement p = conn.prepareStatement(
					"update BankAccount set amount=" + b.getAmount() + " where account_id =" + account_id);
			p.executeUpdate();

			p = conn.prepareStatement("insert into Trans_info values(trans_seq.nextval,?,?,?,?)");
			p.setInt(1, account_id);
			p.setDate(2, new Date(System.currentTimeMillis()));
			p.setDouble(3, amount);
			p.setString(4, "Deposited");
			p.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return b;
	}

	@Override
	public BankBean withdraw(int account_id, double amount) {
		BankBean b = new BankBean();
		Connection conn = DBConnection.getConnection();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from BankBean where account_id=" + account_id);
			while (rs.next()) {
				b.setAccount_id(rs.getInt(1));
				b.setCustomer_name(rs.getString(2));
				b.setAmount(rs.getDouble(4) - amount);
			}
			// System.out.println("new Bal "+b.getAmount());
			PreparedStatement p = conn.prepareStatement(
					"update BankAccount set amount=" + b.getAmount() + " where account_id =" + account_id);
			p.executeUpdate();
			p = conn.prepareStatement("insert into Trans_info values(trans_seq.nextval,?,?,?,?)");
			p.setInt(1, account_id);
			p.setDate(2, new Date(System.currentTimeMillis()));
			p.setDouble(3, amount);
			p.setString(4, "WithDraw");
			p.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return b;
	}

	@Override
	public BankBean fundTransfer(int account_id1, int account_id2, double amount) {
		BankBean b1 = new BankBean();
		Connection conn = DBConnection.getConnection();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from BankBean where account_id=" + account_id1);
			while (rs.next()) {
				b1.setAccount_id(rs.getInt(1));
				b1.setCustomer_name(rs.getString(2));
				b1.setAmount(rs.getDouble(4) - amount);
			}
			// System.out.println("new Bal "+b.getAmount());
			PreparedStatement p = conn.prepareStatement(
					"update BankAccount set amount=" + b1.getAmount() + " where account_id =" + account_id1);
			p.executeUpdate();
			p = conn.prepareStatement("insert into Trans_info values(trans_seq.nextval,?,?,?,?)");
			p.setInt(1, account_id1);
			p.setDate(2, new Date(System.currentTimeMillis()));
			p.setDouble(3, amount);
			p.setString(4, "Fund Transfer To " + account_id2);
			p.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		BankBean b2 = new BankBean();

		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from BankBean where account_id=" + account_id2);
			while (rs.next()) {
				b2.setAccount_id(rs.getInt(1));
				b2.setCustomer_name(rs.getString(2));
				b2.setAmount(rs.getDouble(4) + amount);
			}
			PreparedStatement p = conn.prepareStatement(
					"update BankAccount set amount=" + b2.getAmount() + " where account_id =" + account_id2);
			p.executeUpdate();
			p = conn.prepareStatement("insert into Trans_info values(trans_seq.nextval,?,?,?,?)");
			p.setInt(1, account_id2);
			p.setDate(2, new Date(System.currentTimeMillis()));
			p.setDouble(3, amount);
			p.setString(4, "Fund Transfered From " + account_id1);
			p.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return b1;
	} 

	@Override
	public ArrayList printDetails(int account_id) {
		ArrayList<String> a = new ArrayList<String>();
		Connection conn = DBConnection.getConnection();
		String str = "";
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from Trans_info where account_id=" + account_id);
			while (rs.next()) {
				str = String.valueOf(rs.getInt(1))+"\t\t";
				str+=rs.getInt(2)+"\t\t";
				str+=rs.getDate(3)+"\t\t";
				str+=rs.getDouble(4)+"\t\t";
				str+=rs.getString(5);
				a.add(str);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return a;

	}

	@Override
	public int getId(int account_id) {
		int custId =(int) (Math.random()*10000);
		BankBean bean=new BankBean();
		bean.setAccount_id(custId);
		return custId;
			
	}

}
