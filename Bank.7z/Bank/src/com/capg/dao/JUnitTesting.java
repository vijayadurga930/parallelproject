package com.capg.dao;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capg.bean.BankBean;

public class JUnitTesting {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {}
	BankdaoImpl dao=new BankdaoImpl();
 
	@Test
	public void getBalanceById(){
		BankBean bean=dao.getAccountBalence(12);
		//fail("Not yet implemented");
		//assertNotNull(bean);
		assertTrue(100==bean.getAmount());
	}

}
