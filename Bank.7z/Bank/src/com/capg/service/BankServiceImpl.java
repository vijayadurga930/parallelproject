package com.capg.service;

import java.util.ArrayList;

import com.capg.bean.BankBean;
import com.capg.dao.BankdaoImpl;

public class BankServiceImpl implements IBankService{
	BankdaoImpl dao = new BankdaoImpl();
	@Override
	public BankBean addAccount(BankBean bean) {
		
		return dao.addAccount(bean);
	}

	@Override
	public BankBean getAccountBalence(int account_id) {
	
		return  dao.getAccountBalence(account_id);
	}

	@Override
	public BankBean deposit(int account_id, double amount) {
		// TODO Auto-generated method stub
		return  dao.deposit(account_id, amount);
	}

	@Override
	public BankBean withdraw(int account_id, double amount) {
		// TODO Auto-generated method stub
		return dao.withdraw(account_id, amount);
	}

	@Override
	public BankBean fundTransfer(int account_id1, int account_id2, double amount) {
		// TODO Auto-generated method stub
		return dao.fundTransfer(account_id1, account_id2, amount);
	}

	@Override
	public ArrayList printDetails(int account_id) {
		// TODO Auto-generated method stub
		return dao.printDetails(account_id);
	}

	@Override
	public int getId(int account_id) {
		
		return dao.getId(account_id);
	}



}
