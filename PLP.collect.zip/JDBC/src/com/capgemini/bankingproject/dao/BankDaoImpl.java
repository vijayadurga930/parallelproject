package com.capgemini.bankingproject.dao;




import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.capgemini.bankingproject.bean.Customers;
import com.capgemini.bankingproject.bean.Transaction;
import com.capgemini.bankingproject.exception.BankException;


public class BankDaoImpl implements IBankDao {


	public static Map<Integer, Customers> customerList = new HashMap<>();
	public static Map<Integer, Transaction> transactionList = new HashMap<>();
	

	@Override
	public long addToCustomer(Customers customer) throws BankException {
		int custId =(int) (Math.random()*10000);
		long accountNo = (long) (Math.random()*1000);
		customer.setCustId(custId);
		customer.setAccountNo(accountNo);
		getCustomerList().put(custId, customer);
		System.out.println("Your CustId is:"+ custId);
		return accountNo;

	}
	public static Map<Integer, Customers> getCustomerList() {
		return customerList;
	}
	public static void setCustomerList(Map<Integer, Customers> customerList) {
		BankDaoImpl.customerList = customerList;
	}
	public static Map<Integer,Transaction>  gettransactionList() {
		return transactionList;
	}
	public static void settransactionList(Map<Integer, Transaction> transactionList) {
		BankDaoImpl.transactionList = transactionList;
	}



	@Override
	public void showBalance(int custId) throws BankException {
		Customers customer= BankDaoImpl.customerList.get(custId);
		Set keys= customerList.keySet();
		Iterator iterator =keys.iterator();
		while(iterator.hasNext()){
			int key = (int) iterator.next();
			if( key == custId) {
				double balance = customer.getBalance();
				System.out.println("Your available balance is:"+balance);
			}
	}
	}

	

	@Override
	public int transferFunds(Transaction transaction, int sourceCustId, int destinationCustId) throws BankException {
		int transId= 0;
		double balanceSourceCust = 0.0;
		double balanceDestinationCust = 0.0;
		Customers customer1= BankDaoImpl.customerList.get(sourceCustId);
		Customers customer2= BankDaoImpl.customerList.get(destinationCustId);
		Set keys= customerList.keySet();
		Iterator iterator =keys.iterator();
		while(iterator.hasNext()){
			int key = (int) iterator.next();
			if( key == sourceCustId) {
				balanceSourceCust =customer1.getBalance()- transaction.getAmount();
				if(balanceSourceCust<customer1.getBalance()) {
					transaction.setTransType("Debit");
				}
				else
					transaction.setTransType("Credit");
				customer1.setBalance(balanceSourceCust);
				balanceDestinationCust =customer1.getBalance()+transaction.getAmount();
				customer2.setBalance(balanceDestinationCust);
				break;
				
			}
			
		}
		
		transId = (int) (Math.random()*1000);
		Date transDate = new Date();
		transaction.setTransDate(transDate);
		transaction.setTransId(transId);
		transactionList.put(transId, transaction);
		return transId;
	}

	

	@Override
	public void depositBalance(int custId, double amount) throws BankException {
		Customers customer= BankDaoImpl.customerList.get(custId);
		Set keys= customerList.keySet();
		Iterator iterator =keys.iterator();
		while(iterator.hasNext()){
			int key = (int) iterator.next();
			if( key == custId) {
				double balance = customer.getBalance()+amount;
				customer.setBalance(balance);
				System.out.println("Balance Succefully deposited!!Your available balance is:"+balance);
				
			}
		}
	}

	@Override
	public void withdrawBalance(int custId, double amount) throws BankException {
		Customers customer= BankDaoImpl.customerList.get(custId);
		Set keys= customerList.keySet();
		Iterator iterator =keys.iterator();
		while(iterator.hasNext()){
			int key = (int) iterator.next();
			if( key == custId) {
				double balance = customer.getBalance()-amount;
				customer.setBalance(balance);
				
				System.out.println("Transaction Succesfull!!Your available balance is:"+balance);
			}
		}
	}

	@Override
	public Map<Integer, Transaction> printTransactionDetails(int transId) {
		return BankDaoImpl.gettransactionList();
	}





		}
	

	

	
	

