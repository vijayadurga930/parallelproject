package com.capgemini.bankingproject.utilitty;

import java.time.LocalTime;
import java.util.HashMap;
import java.util.Map;

import com.capgemini.bankingproject.bean.Customers;
import com.capgemini.bankingproject.bean.Transaction;

public class BankRepository {
	Customers customer;
	Transaction trans;
	private static Map<Integer ,Customers> customerEntries=new HashMap<Integer,Customers>();
	private static Map<Integer ,Transaction> transactEntries=new HashMap<Integer,Transaction>();
	
	
	
	public static Map<Integer, Customers> getCustomerEntries() {
		customerEntries.put(101,new Customers(101,"vijji","9087654321","vijji@gmail.com","bamgalore",201, 89000,null));
		customerEntries.put(101,new Customers(102,"sweety","9987644321","sweety@gmail.com","kakinada",203, 88000,null));
		return customerEntries;
	}
	public static void setCustomerEntries(Map<Integer, Customers> customerEntries) {
		BankRepository.customerEntries = customerEntries;
	}
	public static Map<Integer, Transaction> getTransactEntries() {
		//transactEntries.put(901,new Transaction(901,"NEFT",LocalTime.now(), 101, 1001, 5001, 9000 ));
		
		return transactEntries;
	}
	public static void setTransactEntries(Map<Integer, Transaction> transactEntries) {
		BankRepository.transactEntries = transactEntries;
	}
	
	

}
