package com.capgemini.bankingproject.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;

import com.capgemini.bankingproject.bean.Customers;
import com.capgemini.bankingproject.exception.BankException;
import com.capgemini.bankingproject.service.BankServiceImpl;
import com.capgemini.bankingproject.service.IBankService;

public class Test {

	static IBankService serv=null;
	Customers customer=new Customers(0, "ShreyaC","shreya@gmail","100","afdf", 0, 0, null);
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		serv=new BankServiceImpl();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@org.junit.Test
	public void test() {
		try {
			assertNotNull(serv.addToCustomer(customer));
			assertNotEquals(serv.addToCustomer(customer),123);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
