package com.cg.banktest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.bankingproject.bean.Customers;
import com.capgemini.bankingproject.bean.Transaction;
import com.capgemini.bankingproject.dao.BankDaoImpl;
import com.capgemini.bankingproject.dao.IBankDao;
import com.capgemini.bankingproject.exception.BankException;

public class Banktest {

	static IBankDao dao;
	static Customers customer;
	static Transaction transaction;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		dao = new BankDaoImpl();
		customer = new Customers();
		transaction = new Transaction();	
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		dao = null;
		customer = null;
		transaction = null;

	}
	

	@Before
	public void setUp() throws Exception {
		customer = new Customers(101,"vijji","9087654321","vijji@gmail.com","bamgalore",201, 89000,null);

		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAddToCustomer() {
		assertNotNull(customer);

	}
	@Test
	public void testGetCustomerList() throws BankException {
		dao.customerList.clear();
		double custId= dao.addToCustomer(customer);
		assertNotEquals(1,dao.customerList.size()>1);
	}


}

